<?php
namespace app\super\controller;
use think\facade\Db;

class test{
	public function getList(){
		}
}


?>
