<?php

namespace app\super\controller;

use think\facade\Db;

class Upgrade
{
    /**
     * 获取更新版本列表
     */
    public function getList()
    {
        echo "该版本不支持一键更新代码";
    }

    /**
     * 执行升级
     */
    public function doUpgrade()
    {
        echo "该版本不支持一键更新代码";
    }

    /**
     * 获取历史版本列表
     */
    public function getHistory()
    {
        echo "该版本不支持一键更新代码";
    }

    public function checkUpgrade()
    {
        echo "该版本不支持一键更新代码";
    }
}
